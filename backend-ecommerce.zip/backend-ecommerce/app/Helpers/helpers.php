<?php 

if (! function_exists('moneyFormat')) {
    /**
     * moneyFormat
     * 
     * @param mixed $str
     * @return void
     */
    function moneyFormat($str) {
        return 'Rp. ' . number_format(num: $str, decimals: '0', decimal_separator: '', thousands_separator: '.');

    }
}

$angka = 10000;

//format angka dengan helper
$hasil = moneyFormat($angka);

echo $hasil;

//hasilnya akan menampilkan seperti berikut ini : Rp. 10.000
?>